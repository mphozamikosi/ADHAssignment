package controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import model.Customer;

@ManagedBean(name = "customercontroller")
@SessionScoped

public class CustomerController {
	@ManagedProperty(value = "#{customer}")
	private Customer customer;
	
	public void addNewCustomer() {
		System.out.println("Hello");
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	
}
